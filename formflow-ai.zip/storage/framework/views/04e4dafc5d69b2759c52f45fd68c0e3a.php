<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo e($form->title); ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        body { background: #f8fafc; min-height: 100vh; display: flex; align-items: center; justify-content: center; padding: 1rem; }
        .form-card { max-width: 800px; width: 100%; background: white; border-radius: 2rem; box-shadow: 0 20px 60px rgba(0,0,0,0.08); padding: 2.5rem; }
        .form-control { border-radius: 12px; border: 1px solid #e2e8f0; padding: 0.75rem 1rem; transition: all 0.2s; }
        .form-control:focus { border-color: #6c5ce7; box-shadow: 0 0 0 4px rgba(108,92,231,0.12); outline: none; }
        .btn-submit { background: linear-gradient(135deg, #6c5ce7, #4a3db8); border: none; padding: 0.75rem 2rem; border-radius: 60px; font-weight: 600; color: white; transition: all 0.3s; }
        .btn-submit:hover { transform: translateY(-2px); box-shadow: 0 10px 30px rgba(108,92,231,0.3); }
    </style>
</head>
<body>
    <div class="form-card">
        <h1 class="text-3xl font-bold text-gray-800 mb-2"><?php echo e($form->title); ?></h1>
        <?php if($form->description): ?>
            <p class="text-gray-600 mb-6"><?php echo e($form->description); ?></p>
        <?php endif; ?>

        <form method="POST" action="<?php echo e(route('public.form.submit', $form->shareable_link)); ?>">
            <?php echo csrf_field(); ?>
            <?php $__currentLoopData = $form->fields; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="mb-5">
                    <label class="block text-sm font-semibold text-gray-700 mb-1">
                        <?php echo e($field->label); ?>

                        <?php if($field->required): ?> <span class="text-red-500">*</span> <?php endif; ?>
                    </label>

                    <?php switch($field->type):
                        case ('text'): ?>
                        <?php case ('email'): ?>
                        <?php case ('phone'): ?>
                            <input type="<?php echo e($field->type === 'email' ? 'email' : ($field->type === 'phone' ? 'tel' : 'text')); ?>"
                                   name="<?php echo e($field->id); ?>"
                                   class="form-control w-full"
                                   placeholder="<?php echo e($field->placeholder); ?>"
                                   <?php if($field->required): ?> required <?php endif; ?>>
                            <?php break; ?>

                        <?php case ('textarea'): ?>
                            <textarea name="<?php echo e($field->id); ?>"
                                      class="form-control w-full"
                                      rows="4"
                                      placeholder="<?php echo e($field->placeholder); ?>"
                                      <?php if($field->required): ?> required <?php endif; ?>></textarea>
                            <?php break; ?>

                        <?php case ('dropdown'): ?>
                            <select name="<?php echo e($field->id); ?>"
                                    class="form-control w-full"
                                    <?php if($field->required): ?> required <?php endif; ?>>
                                <option value="">Select...</option>
                                <?php $__currentLoopData = $field->options ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($option); ?>"><?php echo e($option); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php break; ?>

                        <?php case ('checkbox'): ?>
                            <div class="flex items-center">
                                <input type="checkbox" name="<?php echo e($field->id); ?>"
                                       class="rounded border-gray-300 text-purple-600 focus:ring-purple-500"
                                       value="1"
                                       <?php if($field->required): ?> required <?php endif; ?>>
                                <label class="ml-2 text-sm text-gray-700">Yes</label>
                            </div>
                            <?php break; ?>

                        <?php case ('radio'): ?>
                            <?php $__currentLoopData = $field->options ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="flex items-center">
                                    <input type="radio" name="<?php echo e($field->id); ?>" value="<?php echo e($option); ?>"
                                           class="border-gray-300 text-purple-600 focus:ring-purple-500"
                                           <?php if($field->required): ?> required <?php endif; ?>>
                                    <label class="ml-2 text-sm text-gray-700"><?php echo e($option); ?></label>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php break; ?>

                        <?php case ('date'): ?>
                            <input type="date" name="<?php echo e($field->id); ?>"
                                   class="form-control w-full"
                                   <?php if($field->required): ?> required <?php endif; ?>>
                            <?php break; ?>

                        <?php case ('file'): ?>
                            <input type="file" name="<?php echo e($field->id); ?>"
                                   class="block w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-purple-50 file:text-purple-700 hover:file:bg-purple-100"
                                   <?php if($field->required): ?> required <?php endif; ?>>
                            <?php break; ?>

                        <?php case ('rating'): ?>
                            <div class="flex gap-2 text-3xl text-yellow-400">
                                <?php for($i = 1; $i <= 5; $i++): ?>
                                    <label>
                                        <input type="radio" name="<?php echo e($field->id); ?>" value="<?php echo e($i); ?>" class="hidden peer">
                                        <i class="fas fa-star peer-checked:text-yellow-400 text-gray-300 hover:text-yellow-400 cursor-pointer"></i>
                                    </label>
                                <?php endfor; ?>
                            </div>
                            <?php break; ?>

                        <?php case ('signature'): ?>
                            <div class="border-2 border-dashed rounded-lg p-6 text-center text-gray-400">
                                <i class="fas fa-pen text-3xl"></i>
                                <p class="text-sm mt-1">Sign here (touch or mouse)</p>
                            </div>
                            <?php break; ?>

                        <?php default: ?>
                            <input type="text" name="<?php echo e($field->id); ?>" class="form-control w-full">
                    <?php endswitch; ?>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <button type="submit" class="btn-submit">Submit</button>
        </form>

        <?php if(session('success')): ?>
            <div class="mt-4 p-4 bg-green-100 text-green-700 rounded-lg">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>
    </div>
</body>
</html><?php /**PATH C:\formflow-ai\resources\views/form-public/show.blade.php ENDPATH**/ ?>