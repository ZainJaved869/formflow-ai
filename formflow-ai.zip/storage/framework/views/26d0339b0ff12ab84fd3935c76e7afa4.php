

<?php $__env->startSection('title', 'Submission #' . $submission->id); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="card card-premium p-4">
        <div class="d-flex justify-content-between align-items-center">
            <h4 class="fw-bold">Submission #<?php echo e($submission->id); ?></h4>
            <a href="<?php echo e(route('submissions.index')); ?>" class="btn btn-outline-secondary rounded-pill">
                <i class="bi bi-arrow-left me-1"></i> Back
            </a>
        </div>
        <hr>
        <div class="row">
            <div class="col-md-6">
                <p><strong>Form:</strong> <?php echo e($submission->form->title); ?></p>
                <p><strong>User:</strong> <?php echo e($submission->user->name ?? 'Guest'); ?></p>
                <p><strong>Submitted at:</strong> <?php echo e($submission->created_at->toDateTimeString()); ?></p>
            </div>
            <div class="col-md-6">
                <div class="bg-light p-3 rounded-3">
                    <h6>Data:</h6>
                    <?php
                        $fieldLabels = $submission->form->fields->pluck('label', 'id')->toArray();
                    ?>
                    <dl class="row mb-0">
                        <?php $__currentLoopData = $submission->data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <dt class="col-sm-4"><?php echo e($fieldLabels[$key] ?? 'Field ' . $key); ?></dt>
                            <dd class="col-sm-8"><?php echo e($value); ?></dd>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </dl>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\formflow-ai\resources\views/submissions/show.blade.php ENDPATH**/ ?>