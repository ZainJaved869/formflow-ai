

<?php $__env->startSection('title', 'Subscription Plans'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row mb-4">
        <div class="col-12">
            <h4 class="fw-bold"><i class="bi bi-credit-card me-2" style="color:#6C63FF;"></i>Subscription Plans</h4>
            <p class="text-muted">Choose the plan that fits your needs. Upgrade or downgrade anytime.</p>
        </div>
    </div>

    <?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?php echo e(session('success')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <div class="row g-4">
        <?php $__currentLoopData = $plans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $plan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-4">
                <div class="card card-premium h-100 p-4 text-center <?php echo e($currentPlan === $key ? 'border border-primary' : ''); ?>">
                    <?php if($currentPlan === $key): ?>
                        <span class="badge bg-primary rounded-pill px-3 py-2 mb-2">Current Plan</span>
                    <?php endif; ?>
                    <h5 class="fw-bold"><?php echo e($plan['name']); ?></h5>
                    <h2 class="fw-bold"><?php echo e($plan['price']); ?><small class="fs-6 text-muted"><?php echo e($plan['period']); ?></small></h2>
                    <ul class="list-unstyled text-start mt-3">
                        <?php $__currentLoopData = $plan['features']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feature): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><i class="bi bi-check-circle-fill me-2" style="color:#6C63FF;"></i><?php echo e($feature); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                    <?php if($currentPlan === $key): ?>
                        <button class="btn btn-outline-secondary rounded-pill w-100" disabled>Current Plan</button>
                    <?php elseif($key === 'free'): ?>
                        <form method="POST" action="<?php echo e(route('subscription.cancel')); ?>">
                            <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-outline-secondary rounded-pill w-100" onclick="return confirm('Downgrade to Free?')">Downgrade</button>
                        </form>
                    <?php else: ?>
                        <form method="POST" action="<?php echo e(route('subscription.store')); ?>">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="plan" value="<?php echo e($key); ?>">
                            <button type="submit" class="btn btn-primary rounded-pill w-100">Upgrade to <?php echo e($plan['name']); ?></button>
                        </form>
                    <?php endif; ?>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <div class="card card-premium p-4 mt-4">
        <h6 class="fw-bold">Need more?</h6>
        <p class="text-muted">Contact us for enterprise plans with custom pricing and dedicated support.</p>
        <a href="#" class="btn btn-outline-primary rounded-pill" style="width:fit-content;">Contact Sales</a>
    </div>
</div>

<style>
    .card-premium {
        background: var(--bs-body-bg);
        backdrop-filter: blur(12px);
        border: 1px solid var(--bs-border-color);
        border-radius: 24px;
        box-shadow: 0 20px 60px rgba(108,99,255,0.08);
        transition: all 0.3s;
    }
    .card-premium:hover {
        transform: translateY(-6px);
        box-shadow: 0 30px 80px rgba(108,99,255,0.12);
    }
</style>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\formflow-ai\resources\views/subscription/index.blade.php ENDPATH**/ ?>