

<?php $__env->startSection('title', 'My Forms'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h3 class="fw-bold">My Forms</h3>
        <a href="<?php echo e(route('forms.create')); ?>" class="btn btn-primary rounded-pill">
            <i class="bi bi-plus-circle me-1"></i> New Form
        </a>
    </div>

    <div class="row g-4">
        <?php $__empty_1 = true; $__currentLoopData = $forms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $form): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="col-md-4">
                <div class="card shadow-sm border-0 rounded-4 h-100">
                    <div class="card-body">
                        <div class="d-flex justify-content-between">
                            <h5 class="card-title fw-bold"><?php echo e($form->title); ?></h5>
                            <span class="badge <?php echo e($form->is_published ? 'bg-success' : 'bg-warning'); ?>">
                                <?php echo e($form->is_published ? 'Active' : 'Draft'); ?>

                            </span>
                        </div>
                        <p class="text-muted small mb-3">
                            <?php echo e($form->submissions_count ?? 0); ?> submissions · <?php echo e($form->created_at->diffForHumans()); ?>

                        </p>
                        <div class="d-flex gap-2 flex-wrap">
                            <a href="<?php echo e(route('forms.edit', $form->id)); ?>" class="btn btn-sm btn-outline-primary rounded-pill">Edit</a>
                            <a href="<?php echo e(route('public.form', $form->shareable_link)); ?>" class="btn btn-sm btn-outline-secondary rounded-pill" target="_blank">View</a>
                            <a href="<?php echo e(route('forms.qr', $form->id)); ?>" class="btn btn-sm btn-outline-info rounded-pill" title="Download QR Code">
                                <i class="bi bi-qr-code"></i>
                            </a>
                            <form method="POST" action="<?php echo e(route('forms.destroy', $form->id)); ?>" class="d-inline">
                                <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-sm btn-outline-danger rounded-pill" onclick="return confirm('Delete this form?')">
                                    <i class="bi bi-trash"></i>
                                </button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="col-12 text-center py-5">
                <i class="bi bi-file-earmark-plus fs-1 text-muted"></i>
                <p class="text-muted mt-2">You haven’t created any forms yet.</p>
                <a href="<?php echo e(route('forms.create')); ?>" class="btn btn-primary rounded-pill">Create Your First Form</a>
            </div>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\formflow-ai\resources\views/forms/index.blade.php ENDPATH**/ ?>