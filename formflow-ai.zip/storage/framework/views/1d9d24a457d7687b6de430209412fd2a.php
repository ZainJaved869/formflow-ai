

<?php $__env->startSection('title', 'Form Templates'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid px-4">
    <h4 class="fw-bold mb-4"><i class="bi bi-grid me-2" style="color:#6C63FF;"></i>Form Templates</h4>
    <p class="text-muted">Start with a pre-built template and customize it to your needs.</p>

    <?php if(isset($categories) && $categories->count()): ?>
        <div class="d-flex flex-wrap gap-2 mb-4">
            <a href="<?php echo e(route('templates.index')); ?>" class="btn btn-outline-primary rounded-pill <?php echo e(!request('category') ? 'active' : ''); ?>">All</a>
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="<?php echo e(route('templates.index', ['category' => $category])); ?>" class="btn btn-outline-primary rounded-pill <?php echo e(request('category') == $category ? 'active' : ''); ?>">
                    <?php echo e(ucfirst($category)); ?>

                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php endif; ?>

    <div class="row g-4">
        <?php $__empty_1 = true; $__currentLoopData = $templates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $template): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="col-md-4 col-lg-3">
                <div class="card card-premium h-100 p-3">
                    <div class="d-flex align-items-center gap-3 mb-2">
                        <i class="<?php echo e($template->icon ?? 'bi bi-file-earmark'); ?>" style="font-size:2rem;color:#6C63FF;"></i>
                        <div>
                            <h6 class="fw-bold mb-0"><?php echo e($template->name); ?></h6>
                            <small class="text-muted"><?php echo e(ucfirst($template->category)); ?></small>
                        </div>
                    </div>
                    <p class="text-muted small" style="flex:1;"><?php echo e(Str::limit($template->description, 80)); ?></p>
                    <div class="d-flex gap-2 mt-2">
                        <a href="<?php echo e(route('templates.use', $template->slug)); ?>" class="btn btn-primary btn-sm rounded-pill w-100">Use Template</a>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="col-12 text-center py-5">
                <i class="bi bi-inbox fs-1 text-muted"></i>
                <p class="text-muted mt-2">No templates available yet.</p>
            </div>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\formflow-ai\resources\views/templates/index.blade.php ENDPATH**/ ?>